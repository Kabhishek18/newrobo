
<br><br><br><br>
<article class="bg-secondary mb-3">  
<div class="card-body text-center">
<h4 class="text-white">Thank you for payment<br></h4>
<h4 class="text-white"><?=$speech?><br></h4>
<br>
<p></p>
</div>
<br><br><br>
</article>