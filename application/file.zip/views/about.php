<!---------------------------------------------------Breadcrumb_Box_Start------------------------------>
<section class="breadcrumb_box about_breadcrumb">
			<div class="container">
				<div class="breadcrumb_text">
					<h1>About Us</h1>
					<h6>About Newrobos</h6>							
				</div>
			</div>
		</section>
		<!---------------------------------------------------breadcrumb_box_End------------------------------>

 

		<!---------------------------------------------------Babout_us_container_Start------------------------------>
		<section class="about_us_container p_t_50 p_b_50">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<!-- <div class="about_right_inner">
							<div class="about_img">
								<div class="image_holder ">
									<img src="<?=base_url()?>assets/img/4.jpg" alt="images" class="<?=base_url()?>assets/img-fuild">
								</div>
								<div class="<?=base_url()?>assets/img_text">
									<h6>Play Time In Kindergarten</h6>
									<span>Tenderhearts Class</span>
								</div>
							</div>
						</div> -->
<style>
.about_us_container .component-divider {
margin-left: auto !important;
}</style>
						<div class="about_left_inner text_center12	">
							<h3 style="text-align:center;">Dedicated courses for<br> <strong>the technology-driven era.</strong></h3>
							<div class="component-divider"></div>
							<div class="component-italic">
									Learn from the best and experienced instructors from the comfort of home. Technology will be a game changer in your life!
							</div>
							<p class="margin-top-3 about_left_text">
								NewRobos is an online coding academy for kids that helps them with a platform where they canlearn to exhibit their creative side which otherwise remains hidden. Our vision is to create a coding boot camp for our students and bring out the innovator in the early years.<br>
								We aim to inspire the individuals who have a knack for programming because coding will be the future language.<br>
								We create a perfect ambiance for our students where they get motivated to learn and create and at the same time enjoy the online sessions.<br>
								Through our courses, we plan to develop young programmerswho can create magic with codes and skills. We have designed our courses keeping in mind the ever-changing market trends and latest technology.<br>
							Having an experience of 15years in Computer Science Education and Robotics makes us a cut above the rest.We focus on imparting education that can help the kids to learn <b>fundamentals of coding-structure sequence, games, animations, make chatbots, gain insight in android through live projects, artificial intelligence and graphical programming, mobile app and game development, loops and lists through memorization games and designing user interface for Android.</b><br>
							Our online classes are self-paced with full attention being paid to all through the formation of small groups. Our training tries to make them proficient and independent so that they can perform on their own as well. <br>
							In this technology-driven era, we offer the beststudent-centered courses at cost-efficient prices which will help your kids to get a head start in this fast-paced and competitive world. <br>
							<b>Be a part of the NewRobos team and let’s create future visionaries, artists, animators and entrepreneurs!</b> 

							</p>

							<!-- <p class="m_T-30"><a href="#" class="component-button yellow_color_t">Learn More <i></i></a></p> -->
						</div>
					</div>
					<div class="col-md-6">
						
					</div>
					<div class="col-md-12">
						<div class="about_content_box">
							<p>
							
							
						</div>
					</div>
				</div>
			</div>
		</section>
		<!---------------------------------------------------Babout_us_container_End------------------------------>





		<!---------------------------------------------------Babout_us_container_Start------------------------------>
		<!-- <section class="about_us_container revers_about p_t_50 p_b_50">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<div class="about_left_inner text_center">
							<h3>Dedicated classrooms with<br> <strong>top skilled educators.</strong></h3>
							<div class="component-divider"></div>
							<div class="component-italic">
									Nulla adiscipling elite forte, nodis est advance pulvinar maecenas est dolor, novum elite lacina.
							</div>
							<p class="margin-top-3">
									Praesent arcu gravida a vehicula est node maecenas loareet maecenas morbi dosis luctus mode. Urna eget lacinia eleifend molibden dosis et gravida dosis sit amet terminal.
							</p>

							<p class="m_T-30"><a href="#" class="component-button yellow_color_t">Learn More <i></i></a></p>
						</div>
					</div>
					<div class="col-md-6">
						<div class="about_right_inner">
							<div class="about_img">
								<div class="image_holder ">
									<img src="<?=base_url()?>assets/img/3.jpg" alt="images" class="<?=base_url()?>assets/img-fuild">
								</div>
								<div class="<?=base_url()?>assets/img_text">
									<h6>Play Time In Kindergarten</h6>
									<span>Tenderhearts Class</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section> -->
		<!---------------------------------------------------about_us_container_End------------------------------>


		<!---------------------------------------------------Babout_us_container_Start------------------------------>
		<!-- <section class="about_us_container  p_t_50 p_b_50">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<div class="about_left_inner text_center">
							<h3>Dedicated classrooms with<br> <strong>top skilled educators.</strong></h3>
							<div class="component-divider"></div>
							<div class="component-italic">
									Nulla adiscipling elite forte, nodis est advance pulvinar maecenas est dolor, novum elite lacina.
							</div>
							<p class="margin-top-3">
									Praesent arcu gravida a vehicula est node maecenas loareet maecenas morbi dosis luctus mode. Urna eget lacinia eleifend molibden dosis et gravida dosis sit amet terminal.
							</p>

							<p class="m_T-30"><a href="#" class="component-button yellow_color_t">Learn More <i></i></a></p>
						</div>
					</div>
					<div class="col-md-6">
						<div class="about_right_inner">
							<div class="about_img">
								<div class="image_holder ">
									<img src="<?=base_url()?>assets/img/2.jpg" alt="images" class="<?=base_url()?>assets/img-fuild">
								</div>
								<div class="<?=base_url()?>assets/img_text">
									<h6>Play Time In Kindergarten</h6>
									<span>Tenderhearts Class</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section> -->
		<!---------------------------------------------------Babout_us_container_End------------------------------>


		<!---------------------------------------------------counter_wrapper_Start------------------------------>
		<section class="counter_wrapper about_counter">
			<div class="container">
				<div class="counter_slider">
			 		<div class="counter_inner">
			 			<div class="counter_box">
			 				logo
			 			</div>
			 			<h5>IIT</h5>
			 			<p>Elementum pulvinar detos diaspis movum blandit.</p>
			 		</div>

			 		<div class="counter_inner">
			 			<div class="counter_box">
			 				logo
			 			</div>
			 			<h5>NIT</h5>
			 			<p>Elementum pulvinar detos diaspis movum blandit.</p>
			 		</div>


			 		<div class="counter_inner">
			 			<div class="counter_box">
			 				logo
			 			</div>
			 			<h5>IIM</h5>
			 			<p>Elementum pulvinar detos diaspis movum blandit.</p>
			 		</div>


			 	<!--	<div class="counter_inner">
			 			<div class="counter_box">
			 				123
			 			</div>
			 			<h5>Full Daycare</h5>
			 			<p>Elementum pulvinar detos diaspis movum blandit.</p>
			 		</div>



			 		<div class="counter_inner">
			 			<div class="counter_box">
			 				123
			 			</div>
			 			<h5>Full Daycare</h5>
			 			<p>Elementum pulvinar detos diaspis movum blandit.</p>
			 		</div>


			 		<div class="counter_inner">
			 			<div class="counter_box">
			 				123
			 			</div>
			 			<h5>Full Daycare</h5>
			 			<p>Elementum pulvinar detos diaspis movum blandit.</p>
			 		</div> -->
				</div>
			</div>
		</section>
		<!---------------------------------------------------counter_wrapper_End------------------------------>

		<!---------------------------------------------------blog_Start------------------------------>
		<!--<section id="blog" class="p_t_50 p_b_50 bottom_box_shadow">-->
		<!--	<div class="container">-->
		<!--		<div class="title">-->
		<!--			<h2>What's New</h2>-->
		<!--			<h6>Keep up to date with the latest news</h6>-->
		<!--			<div></div>-->
		<!--		</div>-->
		<!--		<div class="blog_container welcome_layout">-->
		<!--			<div class="row">-->
		<!--				<div class="col-md-4">-->
		<!--					<div class="blog_box">-->
		<!--						<div class="post_date">-->
		<!--							October 03, 2014-->
		<!--						</div>-->
								
		<!--						<div class="post_img">-->
		<!--							<a href=""><img src="<?=base_url()?>assets/img/7.jpg" alt=""></a>-->
		<!--							<span class="post_no">12</span>-->
		<!--						</div>-->
								
		<!--						<div class="post_title">-->
		<!--							<h2>Drawing and Painting Lessons</h2>-->
		<!--						</div>-->
								
		<!--						<div class="post_text">-->
		<!--							Magna est consectetur interdum modest dictum. Curabitur est faucibus, malesuada esttincidunt etos et mauris, nunc a libero govum est cuprum.-->
		<!--						</div>-->
								
		<!--						<div class="filter_box">-->
		<!--							<ul>-->
		<!--								<li class="author"><a href="">Anna Brown</a></li>-->
		<!--								<li class="category"><a href="">Events, Fun</a></li>-->
		<!--							</ul>-->
		<!--						</div>-->
		<!--					</div>-->
		<!--				</div>-->
						
						
						
		<!--				<div class="col-md-4">-->
		<!--					<div class="blog_box">-->
		<!--						<div class="post_date">-->
		<!--							October 03, 2014-->
		<!--						</div>-->
								
		<!--						<div class="post_img">-->
		<!--							<a href=""><img src="<?=base_url()?>assets/img/7.jpg" alt=""></a>-->
		<!--							<span class="post_no">12</span>-->
		<!--						</div>-->
								
		<!--						<div class="post_title">-->
		<!--							<h2>Drawing and Painting Lessons</h2>-->
		<!--						</div>-->
								
		<!--						<div class="post_text">-->
		<!--							Magna est consectetur interdum modest dictum. Curabitur est faucibus, malesuada esttincidunt etos et mauris, nunc a libero govum est cuprum.-->
		<!--						</div>-->
								
		<!--						<div class="filter_box">-->
		<!--							<ul>-->
		<!--								<li class="author"><a href="">Anna Brown</a></li>-->
		<!--								<li class="category"><a href="">Events, Fun</a></li>-->
		<!--							</ul>-->
		<!--						</div>-->
		<!--					</div>-->
		<!--				</div>-->
						
						
		<!--				<div class="col-md-4">-->
		<!--					<div class="blog_box">-->
		<!--						<div class="post_date">-->
		<!--							October 03, 2014-->
		<!--						</div>-->
								
		<!--						<div class="post_img">-->
		<!--							<a href=""><img src="<?=base_url()?>assets/img/7.jpg" alt=""></a>-->
		<!--							<span class="post_no">12</span>-->
		<!--						</div>-->
								
		<!--						<div class="post_title">-->
		<!--							<h2>Drawing and Painting Lessons</h2>-->
		<!--						</div>-->
								
		<!--						<div class="post_text">-->
		<!--							Magna est consectetur interdum modest dictum. Curabitur est faucibus, malesuada esttincidunt etos et mauris, nunc a libero govum est cuprum.-->
		<!--						</div>-->
								
		<!--						<div class="filter_box">-->
		<!--							<ul>-->
		<!--								<li class="author"><a href="">Anna Brown</a></li>-->
		<!--								<li class="category"><a href="">Events, Fun</a></li>-->
		<!--							</ul>-->
		<!--						</div>-->
		<!--					</div>-->
		<!--				</div>-->
		<!--			</div>-->
					
		<!--			<div class="more_blog">-->
		<!--				<a href=""> go to blog</a>-->
		<!--			</div>-->
		<!--		</div>-->
				
		<!--	</div>-->
		<!--</section>-->
		<!---------------------------------------------------blog_End------------------------------>